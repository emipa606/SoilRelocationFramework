﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using Verse;

namespace SR
{
    [DefOf]
    public static class TerrainDefs
    {
        public static TerrainDef Marsh;
        public static TerrainDef Mud;
    }
}
